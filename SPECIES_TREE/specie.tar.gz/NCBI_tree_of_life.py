#!/usr/bin/env python 
"""
Original work from Jaime Huerta-Cepas
This script is a modification of Jaime work's in order to support deleted nodes 
and node merged into another.
Author: Emmanuel Noutahi
"""
print """ 
This program reads the NCBI taxonomy database (text file format) and
reconstructs the whole taxonomy tree of life. Once loaded, the program
allows you to look up for the specific subtree of a given taxid, or
save the whole tree using the newick format.

Note that reconstructing the from the raw NCBI format may take some
minutes.
"""

import os
import sys 
from string import strip
from ete2 import TreeNode, Tree

# This sets Unbuffered stdout/auto-flush
sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', 0)

id2node= {}
node2parentid = {}
all_ids = set([])
all_nodes = []
id2name= {}
id2uniq_name={}
id_convert={}
del_node=[]

# Loads info from NCBI taxonomy files
if os.path.exists("nodes.dmp"):
    NODESFILE = open('nodes.dmp')
elif os.path.exists("nodes.dmp.bz2"):
    import bz2
    NODESFILE = bz2.BZ2File('nodes.dmp.bz2')
else:
    print '"nodes.dmp" file is missing. Try to re-download it from: ftp://ftp.ncbi.nih.gov/pub/taxonomy/'

if os.path.exists("names.dmp"):
    NAMESFILE = open('names.dmp')
elif os.path.exists("names.dmp.bz2"):
    import bz2
    NAMESFILE = bz2.BZ2File('names.dmp.bz2')
else:
    print '"names.dmp" file is missing. Try re-download it from:  ftp://ftp.ncbi.nih.gov/pub/taxonomy/'

if os.path.exists("merged.dmp"):
    MERGEDFILE = open('merged.dmp')
elif os.path.exists("merged.dmp.bz2"):
    import bz2
    MERGEDFILE = bz2.BZ2File('merged.dmp.bz2')
else:
    print '"merged.dmp" file is missing. Try to download it from: ftp://ftp.ncbi.nih.gov/pub/taxonomy/ '

if os.path.exists("delnodes.dmp"):
    DELFILE = open('delnodes.dmp')
elif os.path.exists("delnodes.dmp.bz2"):
    import bz2
    DELFILE = bz2.BZ2File('delnodes.dmp.bz2')
else:
    print '"delnodes.dmp" file is missing. Try to download it from: ftp://ftp.ncbi.nih.gov/pub/taxonomy/ '

# Reads taxid/names transaltion
print 'Loading species names from "names.dmp" file...',
for line in NAMESFILE:
    line = line.strip()
    fields = map(strip, line.split("|"))
    if(fields[3].find('scientific')!=-1):
        nodeid, name, uniq_name = fields[0], fields[1], fields[2]
        id2name[nodeid] = name
        id2uniq_name[nodeid]= uniq_name

print len(id2name)

# Reads old id and current id 
print 'Loading merged taxid from "merged.dmp" file ...',
for line in MERGEDFILE:
    line= line.strip()
    fields = map(strip, line.split("|"))
    old_id, new_id = fields[0], fields[1]
    id_convert[old_id]= new_id

print len(id_convert)

# Reads old id and current id 
print 'Loading delnode taxid from "delnodes.dmp" file ...',
for line in DELFILE:
    line= line.strip()
    fields = map(strip, line.split("|"))
    del_node.append(fields[0])

print len(del_node)

# Reads node connections in nodes.dmp
print 'Loading node connections from "nodes.dmp" file...', 
for line in NODESFILE:
    line = line.strip()
    fields = map(strip, line.split("|"))
    nodeid, parentid = fields[0], fields[1]
    if nodeid =="" or parentid == "":
	raw_input("Wrong nodeid!")

    # Stores node connections
    all_ids.update([nodeid, parentid])

    # Creates a new TreeNode instance for each new node in file
    n = TreeNode()
    # Sets some TreeNode attributes
    n.add_feature("name", id2name[nodeid])
    n.add_feature("taxid", nodeid)
    n.add_feature("uniq_name", id2uniq_name[nodeid])

    # updates node list and connections
    node2parentid[n]=parentid
    id2node[nodeid] = n
print len(id2node)

# Reconstruct tree topology from previously stored tree connections
print 'Reconstructing tree topology...'
for node in id2node.itervalues():
    parentid = node2parentid[node]
    parent = id2node[parentid]
    # node with taxid=1 is the root of the tree
    if node.taxid == "1":
	t = node
    else:
        parent.add_child(node)

print "The tree contains %d leaf species" %len(t)

save = None
while save!='y' and save!='n':
    save = raw_input("Do you want to save the tree using the newick format?[y|n]").strip().lower()
if save=='y':
    print "Saving tree. This may take some minutes..."
#  open("tree.nw", "w").write( t.write(features=["name","taxid"]) )   
    open("tree.nw", "w").write( t.write())

    print "tree.nw has been created."

# Let's play with the tree
def get_track(node):
    ''' Returns the taxonomy track from leaf to root'''
    track = []
    while node is not None:
        track.append(node.name) # You can add name or taxid
        node = node.up
    print
    return track

#display a specific taxid track
def display_taxid(t=None):
    if t is None and os.path.exists("tree.nw"):
        t=TreeNode("tree.nw")

    taxid = None
    while taxid==None or taxid =='':
        print "================================================="
        taxid = raw_input("Choose the taxid of any taxa group (hit ENTER to quit)\n"+\
                  "Old taxa produces huge trees [e.g. Primates: 9443]:").strip()

    #If taxid is from deleted ID
    if taxid in del_node:
        print "Sorry this taxid is not longer supported in ncbi"
        return

    if taxid in id_convert:
        taxid=id_convert[taxid]
        print "This is an old taxid, the new taxid is: ", taxid

    if taxid in id2name:
        print "Searching for the subtree of: ", id2name[taxid]
        # Node matching the given taxid can be found in the main dict.
        target_node =  id2node[taxid]
        # However, it could also be found by doing:
        # taget_node=t.search_nodes(taxid=whatever)[0] #(Although it
        # would be slower)
        print "found node with %s leaves" %len(target_node)
        print "NCBI taxonomy track:", get_track(target_node)

        show_topo = None
        while not show_topo:
            show_topo = raw_input("Print subtree? [y|n]")
            if show_topo in ["y", "n"]:
                break
        if show_topo  == "y":
            print target_node
    else:
        print "taxid not found"
    print 


display_taxid(t)
